Staffkin Hiring & Onboarding Templates (Canada)
================================================

32 Word templates and 2 PDFs for small Canadian employers, from job posting to the 90-day check-in.
Open the .doc files in Microsoft Word, Google Docs, Pages or LibreOffice. Replace the parts in [brackets].

Hiring: job posting, inclusive job posting language, job posting distribution checklist, phone screen script,
resume screening rubric, behavioural and situational interview questions, work sample assignment,
candidate comparison matrix, interview accommodation request form, reference check consent form,
candidate communication and rejection emails, interview scorecard (PDF).

Offers: offer letter, conditional, fixed-term, seasonal and casual/on-call offer letters, confirmation of employment letter.

Onboarding: pre-boarding emails, new hire information form, direct deposit form, emergency contact form,
first day schedule, first week plan, onboarding buddy guide, manager task list, new hire announcement,
30-60-90 day check-in, probation review checklist, onboarding checklist (PDF).

Also included: return-to-work kit and accessible hiring pack.

General information, not legal advice. Pay, hours, holidays and notice are set by the province or territory
where the work is done. Check https://staffkin.com/employment-standards/ for your province.

Made by Staffkin (staffkin.com), Kentville, Nova Scotia. Questions: contact@staffkin.com
